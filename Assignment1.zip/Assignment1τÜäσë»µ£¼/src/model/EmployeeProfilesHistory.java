/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class EmployeeProfilesHistory {
    
    private ArrayList<EmployeeProfiles> history;
    
    public EmployeeProfilesHistory(){
        
        this.history = new ArrayList<EmployeeProfiles>();
    }

    public ArrayList<EmployeeProfiles> getHistory() {
        return history;
    }

    public void setHistory(ArrayList<EmployeeProfiles> history) {
        this.history = history;
    }
    
    public EmployeeProfiles addNewProfile(){
   
        EmployeeProfiles newProfile = new EmployeeProfiles();
        history.add(newProfile);
        
        return newProfile;
    }
    
    
    public void deleteProfile(EmployeeProfiles ep){
        history.remove(ep);
    }
    
    
    
    
}
    
    

