/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class AppSystem {
    
      
       
    PersonDirectory psd ;
    PatientDirectory ptd;
    EncounterHistory end;
    DoctorDirectory dtd;
    CityDirectory ctd;
    CommunityDirectory cmd;
    HospitalDirectory hpd;

    public AppSystem() {
        this.ctd = new CityDirectory();
        this.psd = new PersonDirectory();
        this.end = new EncounterHistory();
        this.dtd = new DoctorDirectory();
        this.ptd = new PatientDirectory();
        this.cmd = new CommunityDirectory();
        this.hpd = new HospitalDirectory();
    }
    
    public PersonDirectory getPsd() {
        return psd;
    }

    public void setPsd(PersonDirectory psd) {
        this.psd = psd;
    }

    public PatientDirectory getPtd() {
        return ptd;
    }

    public void setPtd(PatientDirectory ptd) {
        this.ptd = ptd;
    }

    public EncounterHistory getEnd() {
        return end;
    }

    public void setEnd(EncounterHistory end) {
        this.end = end;
    }

    public DoctorDirectory getDtd() {
        return dtd;
    }

    public void setDtd(DoctorDirectory dtd) {
        this.dtd = dtd;
    }

    public CityDirectory getCtd() {
        return ctd;
    }

    public void setCtd(CityDirectory ctd) {
        this.ctd = ctd;
    }

    public CommunityDirectory getCmd() {
        return cmd;
    }

    public void setCmd(CommunityDirectory cmd) {
        this.cmd = cmd;
    }

    public HospitalDirectory getHpd() {
        return hpd;
    }

    public void setHpd(HospitalDirectory hpd) {
        this.hpd = hpd;
    }
    
    
    
    
    
    
    public void populate() {
    
    City c = ctd.addNewCity("Boston","6%");
    City b = ctd.addNewCity("New York","8%");
 
    Community hitcom = c.addNewCommunity("Zicon community");
    Community citcom = c.addNewCommunity("Apple community");
    Community bitcom = b.addNewCommunity("Banana community");
    cmd.getCmmdirectory().add(bitcom);
    cmd.getCmmdirectory().add(hitcom);
    cmd.getCmmdirectory().add(citcom);
   
    
   
     House jack230 =citcom.addNewHouse("230 Jack Avenue", "L area","2 miles");
     House rose98 = citcom.addNewHouse("98 Rose Avenue","O area", "1 miles");
     House wary37 = citcom.addNewHouse("37 Wary Alley","P area","0.5 miles");
     House yona38 = bitcom.addNewHouse("38 Yona Street", "I area", "3 miles");
     House john77 = bitcom.addNewHouse("77 John Street", "T area", "1 miles");
     House jeff99 = hitcom.addNewHouse("99 Jeff Street","R area", "2 miles");
     
    
     Patient jack = new Patient(3292011,"Jack",jack230,10,true,"none");
     Patient mary = new Patient(8593822, "Mary",rose98,  30,true, "peanut");
     Patient cici = new Patient(1093930, "Cici",john77, 40 ,false, "none");
     Patient bobby = new Patient(3829203,"Bobby",jeff99,39,false,"none");
        ptd.getPtdirectory().add(jack);
        ptd.getPtdirectory().add(mary);
        ptd.getPtdirectory().add(cici);
        ptd.getPtdirectory().add(bobby);
        
    
     
     
     Hospital big = citcom.addNewHospital("Big Hospital", "Surgical");
     Hospital small = citcom.addNewHospital("Small Hosipital", "Ophthalmology");
     Hospital middle = bitcom.addNewHospital("Middle Hospitsl", "Surgical");
     Hospital sarah = hitcom.addNewHospital("Sarah Hospital", "Ophthalmology");
     hpd.getHptdirectory().add(big);
     hpd.getHptdirectory().add(small);
     hpd.getHptdirectory().add(middle);
     hpd.getHptdirectory().add(sarah);
     
     
    Doctor zoe = new Doctor(8046790,"Zoe", yona38,58,"Surgical","7 years","Tuesday");
    Doctor mike= new Doctor(2798795,"Mike",wary37, 49,"Emergency","5 years","Wednesday");
    Doctor didi = new Doctor(9405964,"Didi",jeff99, 60,"Emergency","2 years","Thursday");
    Doctor jojo = new Doctor(2039001,"Jojo",jeff99, 52,"Ophthalmology","4 years","Friday");
    
    big.getDoctor().add(zoe);
    small.getDoctor().add(mike);
    middle.getDoctor().add(didi);
    sarah.getDoctor().add(jojo);
    
    
    dtd.getDctdirectory().add(zoe);
    dtd.getDctdirectory().add(mike);
    dtd.getDctdirectory().add(didi);
    dtd.getDctdirectory().add(jojo);
    
    
    Encounter jackk = new Encounter();
     jackk.setPatient(jack);
     jackk.setDiagnosis("have a cold");
     jackk.setSymptom("cough");
     jackk.setVitalsigns(new VitalSigns(37.2,120.0,78,"20220705"));
     jackk.setDoctor(zoe);
     
     Encounter maryy = new Encounter();
     maryy.setPatient(mary);
     maryy.setDiagnosis("food poisoning");
     maryy.setSymptom("vomitting");
     maryy.setVitalsigns(new VitalSigns(36.5,110.0,88,"20220920"));
     maryy.setDoctor(mike);
     
     
     Encounter cicii = new Encounter();
     cicii.setPatient(cici);
     cicii.setDiagnosis("pregnant");
     cicii.setSymptom("vomitting");
     cicii.setVitalsigns(new VitalSigns(38.4,140.0,95,"20221026"));
     cicii.setDoctor(jojo);
     
     end.getHistory().add(jackk);
     end.getHistory().add(cicii);
     end.getHistory().add(maryy);
    
    Person bella = new Person(1839202,"Bella",yona38,16);
    psd.getPsdirectory().add(bella);
//    Person jacky = new Person(3292011,"Jack",jack230,10);
    psd.getPsdirectory().add(jack);
    
    
    
    
    }
     
    
}