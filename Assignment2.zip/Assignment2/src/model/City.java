/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class City {
    private String cityname;
    private ArrayList<Community> community;
    private String tax;
   
    
   public City(){
       this.community = new ArrayList<Community>();
           
   }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public ArrayList<Community> getCommunity() {
        return community;
    }

    public void setCommunity(ArrayList<Community> community) {
        this.community = community;
    }
   
    public Community addNewCommunity(String communityName) {
        Community com  = new Community();
        com.setCommunityname(communityName);
        this.community.add(com);
        return com;
    }
    @Override
    public String toString(){
        return cityname;
    }
    
    public Community searchCommunity(String communityname){
        for (Community ss: this.community) {
            if(ss.getCommunityname().equals(communityname)){
                return ss;
            }
        }
        return null;
        
     
        
    }

    public String getTax() {
        return tax;
    }

    public void setTax(String tax) {
        this.tax = tax;
    }
     
   
    
    
    

}