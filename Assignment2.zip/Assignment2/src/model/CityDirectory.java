/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class CityDirectory {
     private ArrayList<City> citdirectory;
     
     
 public CityDirectory(){
    this.citdirectory = new ArrayList<>();
     

    
}
 public City addNewCity(String cityname,String tax){
   
        City newCity = new City();
        newCity.setCityname(cityname);
        newCity.setTax(tax);
        citdirectory.add(newCity);
        
        return newCity;
    }

    public ArrayList<City> getCitdirectory() {
        return citdirectory;
    }

    public void setCitdirectory(ArrayList<City> citdirectory) {
        this.citdirectory = citdirectory;
    }
 
    public City findACity(String cityname) {
        for (City city: this.citdirectory) {
            if(city.getCityname().equals(cityname)) {
                return city;
            }
        }
        return null;
    }
    public City searchCityByCommunityName(String communityname){
        
        for(City cc : this.citdirectory){
            //{ArrayList<House> bb = cc.getHouse();
            //for(House ee : bb)
           /// {if ee
               if(cc.searchCommunity(communityname)!=null)
               return cc;
            }
        return null;
        
        
    }
}
