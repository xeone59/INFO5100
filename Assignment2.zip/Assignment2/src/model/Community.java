/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class Community {
    private String communityname;
    private  ArrayList<House> house;
    private ArrayList<Hospital> hospital;
 

//    public Community() {
//        this.communityname = communityname;
//        this.hospital = hospital;
//        this.house = house;
//    }
    
    public Community() {
     this.house = new ArrayList<>();
     this.hospital = new ArrayList<>();
    }
    
    public void setCommunityname(String communityname) {
        this.communityname = communityname;
    }

    public String getCommunityname() {
        return communityname;
    }
    public House addNewHouse(String housename, String area, String distancehospital) {
        House hou  = new House(housename, area, distancehospital);
        hou.setHousename(housename);
        hou.setArea(area);
        hou.setDistancetohospital(distancehospital);
        this.house.add(hou);
        return hou;
    }
    public Hospital addNewHospital(String hospitalname, String bestdepartment){
        Hospital xx = new Hospital(hospitalname,bestdepartment);
        xx.setBestdepartment(bestdepartment);
        xx.setHospitalname(hospitalname);
        this.hospital.add(xx);
        return xx;
        
    }
    
    public House searchHouse(String housename){
        for (House ss: this.house) {
            if(ss.getHousename().equals(housename)){
                return ss;
            }
        }
        return null;
        
     
        
    }
    public Hospital searchCommunityByHospital(String hospitalname){
        for(Hospital hh : this.hospital)
        {if(hh.getHospitalname().equals(hospitalname))
        {
            return hh;
        }
        }
        return null;
    }

    public ArrayList<House> getHouse() {
        return house;
    }

    public void setHouse(ArrayList<House> house) {
        this.house = house;
    }

    public ArrayList<Hospital> getHospital() {
        return hospital;
    }

    public void setHospital(ArrayList<Hospital> hospital) {
        this.hospital = hospital;
    }
    @Override
    public String toString(){
        return communityname;
    }

    
}
