/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class CommunityDirectory {
    private ArrayList<Community> cmmdirectory;
    
 public CommunityDirectory(){
    this.cmmdirectory = new ArrayList<>();
     

    
}
 public Community searchCommunityByHouseName(String housename){
        
        for(Community cc : this.cmmdirectory){
            //{ArrayList<House> bb = cc.getHouse();
            //for(House ee : bb)
           /// {if ee
               if(cc.searchHouse(housename)!=null)
               return cc;
            }
        return null;
        
        
    }
 
 public Community searchHospital(String hospitalname){
     
     for(Community cc : this.cmmdirectory){
         if(cc.searchCommunityByHospital(hospitalname)!=null)
         
         return cc;
         }
         return null;
     }
     
  

    public ArrayList<Community> getCmmdirectory() {
        return cmmdirectory;
    }

    public void setCmmdirectory(ArrayList<Community> cmmdirectory) {
        this.cmmdirectory = cmmdirectory;
    }
    public Community findACommuniity(String communityname) {
        for (Community community: this.cmmdirectory) {
            if(community.getCommunityname().equals(communityname)) {
                return community;
            }
        }
        return null;
    }
     public Community addNewCommunity(String communityname){
   
        Community newCommunity = new Community();
        newCommunity.setCommunityname(communityname);
        cmmdirectory.add(newCommunity);
        
        return newCommunity;
    }
     
     public Community searchByCommunity(String communityname){
         for(Community dd : this.cmmdirectory){
             if (dd.getCommunityname().equals(communityname)){
                 return dd;
             }
         }return null;
     }
    
    
}
