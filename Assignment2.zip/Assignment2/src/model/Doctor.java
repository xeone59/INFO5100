/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class Doctor extends Person{
    private String department;
    private String workexperience;
    private String clinictime;
    
    public Doctor(long id, String name, House house, int age, String department, String workexperience, String clinictime) {
        super(id, name, house, age);
        
        this.department = department;
        this.clinictime = clinictime;
        this.workexperience = workexperience;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String apartment) {
        this.department = apartment;
    }

    public String getWorkexperience() {
        return workexperience;
    }

    public void setWorkexperience(String workexperience) {
        this.workexperience = workexperience;
    }

    public String getClinictime() {
        return clinictime;
    }

    public void setClinictime(String clinictime) {
        this.clinictime = clinictime;
    }
    
    @Override
     public String toString(){
         return super.getName();
     }
    

    
}