/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class DoctorDirectory {
    private ArrayList<Doctor> dctdirectory;
    
    public DoctorDirectory(){
        
        this.dctdirectory= new ArrayList<>();
        
    }
    public Doctor searchById(long id) {
        
        // search for the object in the arraylist that has name = name passed
        
        for(Doctor tt: this.dctdirectory) {
            
            if(tt.getId() == id) {
                return tt;
            }
        }
        
        return null;
    }
    

    public ArrayList<Doctor> getDctdirectory() {
        return dctdirectory;
    }

    public void setDctdirectory(ArrayList<Doctor> dctdirectory) {
        this.dctdirectory = dctdirectory;
    }
    
    public void deleteDoctor(Doctor dt){
        dctdirectory.remove(dt);
    }
     
    public Doctor addNewDoctor(long id, String name, House house, int age, String department, String workexperience , String clinictime){ 
   
        Doctor newDoctor = new Doctor(id,name,house,age,department,workexperience,clinictime);
        dctdirectory.add(newDoctor);
     
        return newDoctor;
    }


    
}