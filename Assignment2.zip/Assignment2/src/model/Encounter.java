/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class Encounter {
     private Doctor doctor;
     private Patient patient;
     private String symptom;
     private String diagnosis;
     private VitalSigns vitalsigns;

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }
    

    public void setSymptom(String symptom) {
        this.symptom = symptom;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public void setVitalsigns(VitalSigns vitalsigns) {
        this.vitalsigns = vitalsigns;
    }

    public String getSymptom() {
        return symptom;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public VitalSigns getVitalsigns() {
        return vitalsigns;
    }
     @Override
     public String toString(){
         return symptom;
     }
     
    
     
     

     

    
    
    
}
    
     
     
     
    

