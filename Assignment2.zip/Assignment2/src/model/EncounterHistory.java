/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class EncounterHistory {
     private ArrayList<Encounter> history;
    
    public EncounterHistory(){
        
        this.history = new ArrayList<Encounter>();
        
    }
    
    public ArrayList<Encounter> getHistory() {
        return history;
    }

    public void setHistory(ArrayList<Encounter> history) {
        this.history = history;
    }
    
    public Encounter addNewEncounter(){
   
        Encounter newEncounter = new Encounter();
        history.add(newEncounter);
     
        return newEncounter;
    }
    
    
    public void deleteEncounter(Encounter enc){
        history.remove(enc);
    }
    
    public ArrayList<Encounter> searchById(long id) {
        
        // search for the object in the arraylist that has name = name passed
        
        ArrayList<Encounter> zzz = new ArrayList<>();
        
        for(Encounter ep: this.history) {
            if(ep.getPatient().getId()== id) {
                zzz.add(ep);
            }
        }
        
        return zzz;
    }
    
    public ArrayList<Encounter> searchByDoctorId(long id) {
        
        // search for the object in the arraylist that has name = name passed
        
        ArrayList<Encounter> zzz = new ArrayList<>();
        
        for(Encounter ep: this.history) {
            if(ep.getDoctor().getId()== id) {
                zzz.add(ep);
            }
        }
        
        return zzz;
    }
    

    
}
