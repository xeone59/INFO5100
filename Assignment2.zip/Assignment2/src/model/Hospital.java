/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class Hospital {
    private ArrayList <Doctor> doctor;
    private String hospitalname;
    private String bestdepartment;
    
    public Hospital(String hospitalname, String bestdepartent){
        this.doctor = new ArrayList<>();
    }
    
    public ArrayList<Doctor> getDoctor() {
        return doctor;
    }

    public void setDoctor(ArrayList<Doctor> doctor) {
        this.doctor = doctor;
    }

    public Doctor findDoctorByName(String doctorname){
        for (Doctor dd : this.doctor)
        {if (dd.getName().equals(doctorname))
                return dd;
            
        }
        return null;
    }

    public String getHospitalname() {
        return hospitalname;
    }

    public void setHospitalname(String hospitalname) {
        this.hospitalname = hospitalname;
    }

    public String getBestdepartment() {
        return bestdepartment;
    }

    public void setBestdepartment(String bestdepartment) {
        this.bestdepartment = bestdepartment;
    }
    
    @Override
     public String toString(){
         return hospitalname;
     }
    
    
}
    

    
 


 
    
 
    

