/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class HospitalDirectory {
    private ArrayList<Hospital> hptdirectory;
    
    public HospitalDirectory(){
        this.hptdirectory = new ArrayList<Hospital>();
        
    }
    

        

    public void deleteHospital(Hospital hp){
        hptdirectory.remove(hp);
    }
    
    
    public Hospital findHospitalByDocotor(String doctorname){
        for(Hospital hh : this.hptdirectory)
        {
            if(hh.findDoctorByName(doctorname)!=null)
              return hh;
            
        }
        return null;
    }

    public ArrayList<Hospital> getHptdirectory() {
        return hptdirectory;
    }

    public void setHptdirectory(ArrayList<Hospital> docdirectory) {
        this.hptdirectory = docdirectory;
    }
    
    public Hospital findHospitalByHospitalName(String hospitalname){
        for (Hospital ss : this.hptdirectory)
        {
            if (ss.getHospitalname().equals(hospitalname))
                    return ss;
        }
        return null;
    }
    
}
    


