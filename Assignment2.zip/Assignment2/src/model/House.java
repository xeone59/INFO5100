/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class House {
    private String housename;
    private String area;
    private String distancetohospital;
    
public House(String housename, String area, String distancehospital){
        this.housename = housename;
        this.area = area;
        this.distancetohospital = distancehospital;
    }

    public String getHousename() {
        return housename;
    }

    public void setHousename(String housename) {
        this.housename = housename;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDistancetohospital() {
        return distancetohospital;
    }

    public void setDistancetohospital(String distancetohospital) {
        this.distancetohospital = distancetohospital;
    }
    
    @Override
     public String toString(){
         return housename;
     }
     
    
    
    
    
    
    
    
}
