/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class Patient extends Person{
    private boolean insurance;
    private String allergic;

    public Patient(long id, String name, House house, int age, boolean insurance, String allergic) {
        super(id, name, house , age);
        this.allergic = allergic;
        this.insurance = insurance;
    }

    
    
   public long getId(){
       return super.getId();
   }

    public boolean isInsurance() {
        return insurance;
    }

    public void setInsurance(boolean insurance) {
        this.insurance = insurance;
    }

    public String getAllergic() {
        return allergic;
    }

    public void setAllergic(String allergic) {
        this.allergic = allergic;
    }
   @Override
     public String toString(){
        return super.getId()+"";
     }
   
    }
    

