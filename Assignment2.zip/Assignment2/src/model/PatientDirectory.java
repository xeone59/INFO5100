/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class PatientDirectory {
    private ArrayList<Patient> ptdirectory;
   


public PatientDirectory(){
    this.ptdirectory = new ArrayList<>();
       
   
}

    public ArrayList<Patient> getPtdirectory() {
        return ptdirectory;
    }

    public void setPtdirectory(ArrayList<Patient> ptdirectory) {
        this.ptdirectory = ptdirectory;
    }
    



public Patient searchById(long id) {
        
        // search for the object in the arraylist that has name = name passed
        
//        ArrayList <Patient> pts = new ArrayList<>();
      

   for(int i=0; i<ptdirectory.size();i++)
        
//        for(Patient pt: this.ptdirectory) {
            
   {if(ptdirectory.get(i).getId() == id) {
               
                
            
         return ptdirectory.get(i);
}
   
}
   return null;
}

public Patient addNewPatient(long id, String name, House house, int age, boolean insurance, String allergic){
   
        Patient newPatient = new Patient(id,name,house,age,insurance,allergic);
        ptdirectory.add(newPatient);
     
        return newPatient;
    }

public void deletePatient(Patient pt){
        ptdirectory.remove(pt);
    }
}
       

        
           
        
  



        
        

        

        
   


