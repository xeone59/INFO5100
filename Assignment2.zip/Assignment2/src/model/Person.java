/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class Person {
    private long id;
    private String name;
    private int age;
    private House house;
    
    public Person(long id, String name, House house, int age){
    this.age = age;
    this.id = id;
    this.name = name;
    this.house = house;
  
}

    
    public long getId() {
        return id;
        // TODO code application logic here
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public int getAge() {
        return age;
    }

    
    public void setAge(int age) {    
        this.age = age;
    }

    
    

    public static void main(String[] args) {
        // TODO code application logic here
    }

    public House getHouse() {
        return house;
    }

    public void setHouse(House house) {
        this.house = house;
    }
    
    
}
