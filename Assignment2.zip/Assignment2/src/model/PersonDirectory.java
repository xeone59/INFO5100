/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author seona
 */
public class PersonDirectory {
    private ArrayList<Person> psdirectory;

    
  public PersonDirectory(){
        
        this.psdirectory = new ArrayList<Person>();
        
        
    }

    public ArrayList<Person> getPsdirectory() {
        return psdirectory;
    }

    public void setPsdirectory(ArrayList<Person> psdirectory) {
        this.psdirectory = psdirectory;
        
    }
        
     public Person searchById(long id) {
        
        // search for the object in the arraylist that has name = name passed
        
        for(Person ps: this.psdirectory) {
            
            if(ps.getId() == id) {
                return ps;     
            }
        }
        
        return null;
    }
    }
  
  
  
  
  
  
   