/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author seona
 */
public class VitalSigns {
    private double temperature;
    private double bloodPresure;
    private int pulse;
    private String date;
    
 public VitalSigns(double temperature,double bloodPressure, int pulse,String date){
     this.bloodPresure = bloodPressure;
     this.date = date;
     this.pulse = pulse;
     this.temperature = temperature;
 }

    

    

   
    

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getBloodPresure() {
        return bloodPresure;
    }

    public void setBloodPresure(double bloodPresure) {
        this.bloodPresure = bloodPresure;
    }

    public int getPulse() {
        return pulse;
    }

    public void setPulse(int pulse) {
        this.pulse = pulse;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    
    
    
}
